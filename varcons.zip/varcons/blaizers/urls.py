from django.urls import path
from . import views

urlpatterns=[
    path("",views.home),
    path("aboutus/",views.aboutus),
    path("career/",views.career),
    path("support/",views.support)
]