from django.shortcuts import render
from django.template.context import RequestContext

def home(request):
    return render(request,"index.html")

def aboutus(request):
    return render(request,"aboutus.html")

def career(request):
    return render(request,"career.html")

def support(request):
    return render(request,"support.html")