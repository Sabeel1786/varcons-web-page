from django.apps import AppConfig


class BlaizersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'blaizers'
